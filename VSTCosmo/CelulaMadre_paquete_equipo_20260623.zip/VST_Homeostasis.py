#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
VST_Homeostasis — HOMEOSTASIS SCALE-INVARIANT Y EXPANSIÓN MULTICELULAR  ·  "QUIÉN SOY"
================================================================================

QUÉ ES ESTE ARCHIVO
-------------------
La homeostasis del organismo cosmosemiótico, implementada como un organelo
REUTILIZABLE Y SCALE-INVARIANT, más la capa MULTICELULAR que emerge de aplicarlo a
una escala mayor. Importa el motor del genoma (VST_Genoma.py) y los bloques 5/7/8.

EL PRINCIPIO (por qué homeostasis "se expande a multicelular por definición")
-----------------------------------------------------------------------------
La homeostasis es mantener una variable regulada dentro de su rango viable
(C-N5.1: x(t)∈[x_min,x_max]; O-N6.1: fitness=f(A_sys-env)). Es la H del Índice de
Organismicidad (OI, O-N9.14). Por UNIVERSALIDAD ESTRUCTURAL (C-N2.8.14: los
invariantes son universales en función, su valor se calibra por dominio), la MISMA
lógica homeostática opera a tres escalas con el mismo código:
  · ORGANELO  — cada organelo se autorregula (economía, fuga de fatiga).
  · CÉLULA    — un homeostato mantiene el medio interno en rango (da la H del OI).
  · MULTICELULAR — un homeostato COLECTIVO mantiene el acoplamiento del conjunto.
Por eso el salto a multicelular es "por definición": un organismo multicelular ES
un homeostato sobre sus células (igual que la célula es un homeostato sobre sus
organelos). El ejemplo canónico de las hormigas (C-N2.8.14a): termorregulación
COLECTIVA, memoria externalizada (feromonas = S_shared), organismicidad de colonia.

LO QUE LA MULTICELULARIDAD DESBLOQUEA EN EL OI
----------------------------------------------
El OI tenía dos componentes en cero a nivel célula: H (homeostasis) y ME (memoria
externalizada = S_shared, Dicc.146). La homeostasis activa H. La MULTICELULARIDAD
activa ME: el medio compartido (el "aire" de la díada) ES la memoria externalizada.
Con H y ME activos, el OI colectivo puede cruzar a ORGANISMO PLENO (≥0.7).

GUARDA ANTI-SHANNON (no negociable)
-----------------------------------
Que el código pueda AGREGAR células en un colectivo NO significa que el colectivo sea
un organismo VOLUNTARIO. La cohesión voluntaria (Ψ_alma sujeto-sujeto vs desalmamiento,
O-N3.4b) está gobernada por el LOCUS DE ALTRUISMO DE BOORMAN, que sigue RESERVADO Y
VACÍO (PRE, O-N8.19). Por tanto, esta `Multicelula` implementa la DEFINICIÓN estructural
del organismo multicelular (homeostato colectivo + S_shared), pero su cohesión es por
ahora ANDAMIAJE IMPUESTO: el organismo multicelular EMERGENTE/voluntario espera el
desarrollo del locus. Se reporta el OI colectivo marcando esta condición.

KLEIBER A ESCALA (O-N nuestro, extensión)
-----------------------------------------
El multicelular tiene M (complejidad) mayor → por la ley de Kleiber, MENOR metabolismo
por unidad (r↓) y tiempos más largos (s↑): la colonia es "el elefante" frente a la
célula "ratón". El demo lo muestra.
================================================================================
"""

from __future__ import annotations
from typing import Any

from VST_Genoma import (
    Organelo, Estado, Organismo, Milieu, KAPPA, MedidorComplejidad,
)


# ==============================================================================
# ORGANELO HOMEOSTASIS — SCALE-INVARIANT  (C-N5.1 · O-N6.1 · componente H del OI)
# ==============================================================================
class OrganeloHomeostasis(Organelo):
    """Homeostasis: mantiene una variable regulada dentro de su rango viable.

    QUÉ HACE (canon C-N5.1 x(t)∈[x_min,x_max]; O-N6.1 fitness=f(A_sys-env)): sostiene
    una variable interna `x` cerca de un setpoint x0, resistiendo una perturbación del
    entorno. Mide la CALIDAD de regulación H∈[0,1] (1 = perfectamente centrada; 0 = en
    el borde o fuera). H es el componente de homeostasis del OI (O-N9.14).
    CÓMO: ODE de regulación  dx = (perturbación − kp·(x−x0))·dt; H = 1 − |x−x0|/semirango.
    SCALE-INVARIANT: parametrizado por la señal que regula y su rango, el MISMO organelo
    sirve a nivel célula (regula el medio interno) y a nivel colectivo (regula el
    acoplamiento del conjunto). Universalidad estructural (C-N2.8.14): la función es
    universal, los valores (x0, rango, kp) se calibran por dominio.
    KLEIBER: la ganancia efectiva se ralentiza con el tempo s(M) (sistemas más complejos
    regulan más lento, como el metabolismo del elefante).
    """

    def __init__(self, variable: str = "x_interna", x0: float = 0.5,
                 x_min: float = 0.0, x_max: float = 1.0, kp: float = 0.5,
                 perturb: str = "e_R", perturb_escala: float = 0.01,
                 salida: str = "H_homeostasis") -> None:
        super().__init__(
            nombre=f"homeostasis::{variable}", organelo_analogo="termostato / hipotálamo",
            procedencia="C-N5.1 / O-N6.1 / Dicc. (componente H del OI)",
            nodo_canonico="C-N5.1 (x∈[x_min,x_max]) · O-N6.1 · O-N9.14 (H del OI)",
            descripcion=(f"Mantiene '{variable}' en su rango viable resistiendo perturbación. "
                         f"H∈[0,1]=calidad de regulación. Scale-invariant (célula y colectivo)."),
            lee=[perturb],
            secreta=[salida, variable, f"{variable}_en_rango"],
            depende_de=[],
            costo_base=1.0,
            plast={"x0": x0, "x_min": x_min, "x_max": x_max, "kp": kp,
                   "perturb_escala": perturb_escala},
            criterio="H alto sostenido (variable centrada en su rango viable)",
            estado=Estado.PRESENTE,
        )
        self.variable = variable
        self.perturb = perturb
        self.salida = salida
        self.x = x0
        self.H = 1.0

    def percibir(self, milieu: "Milieu") -> None:
        # la perturbación es el estrés del entorno (p.ej. el error operativo)
        self._dist = abs(milieu.leer(self.perturb, 0.0)) * self.plast["perturb_escala"]

    def metabolizar(self, dt: float, tempo: float) -> None:
        p = self.plast
        kp = p["kp"] / tempo            # Kleiber: regula más lento a mayor complejidad
        # dx/dt = perturbación − corrección proporcional hacia el setpoint
        self.x += (self._dist - kp * (self.x - p["x0"])) * dt
        # excursión acotada (no sale del rango duro + un margen)
        self.x = max(p["x_min"] - 0.1, min(p["x_max"] + 0.1, self.x))
        semirango = (p["x_max"] - p["x_min"]) / 2.0
        centro = (p["x_max"] + p["x_min"]) / 2.0
        self.H = max(0.0, 1.0 - abs(self.x - centro) / semirango)

    def secretar(self, milieu: "Milieu") -> None:
        milieu.secretar(self.salida, self.H)
        milieu.secretar(self.variable, self.x)
        p = self.plast
        milieu.secretar(f"{self.variable}_en_rango", p["x_min"] <= self.x <= p["x_max"])


# ==============================================================================
# CÉLULA HOMEOSTÁTICA — homeostasis aplicada a la propia célula
# ==============================================================================
def transcribir_celula_homeostatica() -> Organismo:
    """El organismo completo (B5+B7+B8) MÁS homeostasis a nivel célula. La H activa el
    componente de homeostasis del OI: la célula sube de protoorganismo hacia organismo,
    aunque le falta ME (memoria externalizada) — que solo aparece en el colectivo."""
    from VST_Bloque08_DinamicaEvolutiva import transcribir_organismo_completo
    o = transcribir_organismo_completo()
    # homeostato celular: regula un estado interno frente al error operativo
    o.expresar(OrganeloHomeostasis(variable="x_interna", x0=0.5, x_min=0.0, x_max=1.0,
                                   kp=0.5, perturb="e_R", perturb_escala=0.01))
    o.nombre = "celula_madre_homeostatica"
    return o


# ==============================================================================
# MULTICÉLULA — el organismo a la escala siguiente (homeostasis colectiva + S_shared)
# ==============================================================================
class Multicelula:
    """Un organismo MULTICELULAR: varias células que comparten un MEDIO EXTERNO (el
    "aire" = S_shared) sobre el cual opera una homeostasis COLECTIVA. Por universalidad
    estructural, es un Organismo a la escala siguiente: un homeostato sobre sus células,
    como la célula es un homeostato sobre sus organelos.

    MEMBRANA INTER-CELULAR: tras vivir, cada célula EXPORTA un resumen de su estado
    (LF, XE, acoplamiento, H) al aire compartido. El aire ES la memoria externalizada
    (ME = S_shared): por primera vez ME>0 en el OI.

    HOMEOSTASIS COLECTIVA: un OrganeloHomeostasis (el mismo código, otra escala) regula
    el acoplamiento colectivo (media de las células) → H colectivo.

    KLEIBER COLECTIVO: M_colectivo = Σ M_células → la colonia es más lenta y eficiente
    por unidad (el elefante).

    GUARDA: la cohesión aquí es ANDAMIAJE IMPUESTO. El organismo multicelular VOLUNTARIO
    (Ψ_alma sujeto-sujeto vs desalmamiento) espera el locus de altruismo de Boorman
    (PRE, reservado). Se reporta el OI colectivo MARCANDO esta condición.
    """

    # pesos del OI (idénticos a Organismo.salud, O-N9.14) — calibrables por dominio
    _W = {"H": 0.25, "ME": 0.20, "XE": 0.20, "LF": 0.35}

    def __init__(self, celulas: list[Organismo], M0: float = 1.0) -> None:
        self.celulas = celulas
        self.aire = Milieu()                          # medio compartido = S_shared
        self.complejidad = MedidorComplejidad(M0)     # Kleiber a escala colectiva
        # homeostato colectivo: regula el acoplamiento colectivo A hacia un rango viable
        self.homeostato = OrganeloHomeostasis(
            variable="A_colectivo", x0=0.7, x_min=0.3, x_max=1.0, kp=0.5,
            perturb="estres_colectivo", perturb_escala=0.2, salida="H_colectivo")
        self.t = 0.0
        self.M_colectivo = M0

    def vivir_un_paso(self, dt: float) -> None:
        # 1) cada célula vive su propio ciclo metabólico (es autónoma)
        for c in self.celulas:
            c.vivir_un_paso(dt)
        # 2) MEMBRANA: cada célula exporta su resumen al aire compartido (S_shared)
        for i, c in enumerate(self.celulas):
            self.aire.secretar(f"cel{i}_LF", c.milieu.leer("LF", 0.0))
            self.aire.secretar(f"cel{i}_XE", c.milieu.leer("XE", 0.0))
            self.aire.secretar(f"cel{i}_A", c.milieu.leer("A_sys_env", 0.0))
            self.aire.secretar(f"cel{i}_H", c.milieu.leer("H_homeostasis", 0.0))
        # 3) agregación colectiva (medias) + estrés colectivo (desvío del acoplamiento)
        n = len(self.celulas)
        A_col = sum(c.milieu.leer("A_sys_env", 0.0) for c in self.celulas) / n
        self.aire.secretar("estres_colectivo", max(0.0, 0.7 - A_col))  # cuánto baja del objetivo
        # 4) homeostato COLECTIVO sobre el aire (mismo organelo, otra escala)
        self.homeostato.percibir(self.aire)
        self.homeostato.metabolizar(dt, self._tempo_colectivo())
        self.homeostato.secretar(self.aire)
        self.t += dt

    def _tempo_colectivo(self) -> float:
        # Kleiber colectivo: M = Σ M_células
        self.M_colectivo = max(self.complejidad.M0,
                               sum(c.complejidad.M for c in self.celulas))
        return (self.M_colectivo / self.complejidad.M0) ** 0.25

    def salud_colectiva(self) -> dict[str, Any]:
        """OI colectivo (O-N9.14) sobre el medio compartido. ME>0 porque el aire ES la
        memoria externalizada (S_shared)."""
        n = len(self.celulas)
        H_col = self.aire.leer("H_colectivo", 0.0)
        LF_col = sum(c.milieu.leer("LF", 0.0) for c in self.celulas) / n
        XE_col = sum(c.milieu.leer("XE", 0.0) for c in self.celulas) / n
        # ME = riqueza de la memoria externalizada compartida (nº de aportes en el aire)
        aportes = len([k for k in self.aire.senales if k.startswith("cel")])
        ME = min(1.0, aportes / (n * 2.0))   # ~1 cuando las células comparten su estado
        w = self._W
        OI = w["H"]*H_col + w["ME"]*ME + w["XE"]*min(1.0, XE_col) + w["LF"]*min(1.0, LF_col)
        OI = max(0.0, min(1.0, OI))
        nivel = ("organismo pleno" if OI >= 0.7
                 else "protoorganismo" if OI >= 0.4 else "no organismal")
        s = self._tempo_colectivo()
        return {"H_col": H_col, "ME": ME, "XE_col": XE_col, "LF_col": LF_col,
                "OI": OI, "nivel_OI": nivel, "M_colectivo": self.M_colectivo,
                "tempo_s": s, "eficiencia_r": (self.M_colectivo / self.complejidad.M0) ** -0.25}

    def quien_soy(self) -> str:
        s = self.salud_colectiva()
        return (
            "=" * 80 + "\n"
            f"QUIÉN SOY — organismo MULTICELULAR ({len(self.celulas)} células)\n"
            + "=" * 80 + "\n"
            f"  Kleiber colectivo: M={s['M_colectivo']:.1f}  s(M)={s['tempo_s']:.2f} (más lento)  "
            f"r(M)={s['eficiencia_r']:.3f} (más eficiente/unidad)\n"
            f"  componentes OI:  H_col={s['H_col']:.3f}  ME(S_shared)={s['ME']:.3f}  "
            f"XE_col={s['XE_col']:.3f}  LF_col={s['LF_col']:.3f}\n"
            f"  → OI colectivo = {s['OI']:.3f} → {s['nivel_OI'].upper()}\n"
            f"  ⚠ cohesión = ANDAMIAJE IMPUESTO; organismo VOLUNTARIO pendiente del locus de "
            f"Boorman (PRE, reservado).\n"
            + "=" * 80
        )


# ==============================================================================
# DEMO / AUTOVERIFICACIÓN
# ==============================================================================
if __name__ == "__main__":
    # --- 1) Homeostasis aplicada a la propia célula: activa H del OI ---
    cel = transcribir_celula_homeostatica()
    for _ in range(2000):
        cel.vivir_un_paso(0.1)
    h = cel.organelos["homeostasis::x_interna"]
    s = cel.salud()
    print("=" * 80)
    print("HOMEOSTASIS A NIVEL CÉLULA (B5+B7+B8 + homeostasis):")
    print(f"  x_interna={h.x:.3f} (rango [0,1])  H={h.H:.3f}")
    print(f"  → OI={s['OI']:.3f} → {s['nivel_OI'].upper()}  (H activo; ME aún 0: falta el colectivo)")

    # --- 2) Expansión multicelular POR DEFINICIÓN: misma homeostasis, otra escala ---
    print()
    colonia = Multicelula([transcribir_celula_homeostatica() for _ in range(3)])
    for _ in range(2000):
        colonia.vivir_un_paso(0.1)
    print(colonia.quien_soy())
    sc = colonia.salud_colectiva()
    print(f"\n  COMPARACIÓN DE ESCALA:")
    print(f"    célula:       OI={s['OI']:.3f} ({s['nivel_OI']})   — ME=0")
    print(f"    multicelular: OI={sc['OI']:.3f} ({sc['nivel_OI']}) — ME={sc['ME']:.2f} (S_shared activa)")
    print(f"    La homeostasis es la MISMA (scale-invariant); el salto a organismo lo da ME (S_shared).")
