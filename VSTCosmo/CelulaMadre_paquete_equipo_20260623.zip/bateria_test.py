#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batería de tests de la Célula Madre Funcional (cargador universal + binaural + dos fuentes
+ ablación). Corre 6 suites, guarda CSV por corrida y un JSON resumen en CelulaMadre_logs/,
e imprime una tabla por suite. Los hallazgos se interpretan en INFORME_BATERIA_Test.md.
"""
import os, json, numpy as np
from datetime import datetime
import VST_CelulaMadre_WebLive as W
cmf = W.cmf
AUD = "audio_binaural"
SIM = 6.0
os.makedirs("CelulaMadre_logs", exist_ok=True)
TS = "20260623"

def cargar_mono(spec, rms=None):
    if spec.startswith("demo:"):
        nom, a = cmf.cargar_audio(spec, binaural=False); fmt = "demo"
    else:
        a = cmf._load_wav(os.path.join(AUD, spec), binaural=False); nom = spec; fmt = cmf._FMT_ULTIMO
    if rms is not None:
        r = float(np.sqrt(np.mean(a ** 2)))
        a = np.clip(a * (rms / (r + 1e-9)), -1.0, 1.0)
    return nom, a, fmt

def run_audio(audio, binaural, toggles=None, sim_s=SIM, guardar=None):
    toggles = toggles or {}
    cel = cmf.celula_madre_funcional(audio, binaural=binaural)
    apag = []
    for n, o in cel.organelos.items():
        if n != "soma" and not toggles.get(n, True):
            o.expresar = False; apag.append(n)
    soma = cel.organelos["soma"]; pasos = max(1, int(min(soma.dur, sim_s) / cmf.DT))
    rows = []; cm_peak = 0.0
    for _ in range(pasos):
        cel.vivir_un_paso(cmf.DT); rows.append(W._fila(cel))
        cm_peak = max(cm_peak, cel.milieu.leer("C_m", 0.0))
    med = lambda k: round(float(np.mean([r[k] for r in rows])), 4)
    res = {"OI": rows[-1]["OI"], "R2": rows[-1]["R2"], "XE": rows[-1]["XE"], "C_m_pico": round(cm_peak, 3),
           "Lambda": rows[-1]["Lambda_Cos"], "Omega": med("Omega"), "e_R": med("e_R"),
           "lateralidad": med("lateralidad"), "coher": med("coherencia_biaural"), "balance": med("balance_LR"),
           "lat_real": bool(soma.lateralidad_real), "apagados": apag}
    if guardar:
        cab = f"# {guardar} | binaural={binaural} | apagados={','.join(apag) or 'ninguno'}\n"
        with open(f"CelulaMadre_logs/{guardar}.csv", "w", encoding="utf-8") as f:
            f.write(cab + ",".join(W.COLS) + "\n" + "\n".join(",".join(str(r[c]) for c in W.COLS) for r in rows))
    res["_csv"] = rows
    return res

RES = {}

# ---------- A. Cobertura de formatos ----------
print("=" * 104); print("SUITE A — Cobertura de formatos (cargador universal)"); print("=" * 104)
A = ["BigBang_pos60deg.wav", "Brandemburgo.wav", "Ondas mixtas.wav", "Voz_Estudio_pos60deg.wav",
     "musica_pos60deg.wav", "Ruido blanco_neg60deg.wav", "La_pos60deg.wav", "freq_439_pos60deg_largo.wav"]
print(f"  {'archivo':<30}{'formato':<20}{'muestras':>10}{'rango':>16}{'OI':>7}  finito")
ra = []
for f in A:
    try:
        nom, a, fmt = cargar_mono(f)
        r = run_audio(a, False, sim_s=4.0)
        finito = bool(np.all(np.isfinite(a)))
        print(f"  {f[:29]:<30}{fmt:<20}{a.shape[0]:>10}{('[%.2f,%.2f]'%(a.min(),a.max())):>16}{r['OI']:>7}  {'✅' if finito else '❌'}")
        ra.append({"archivo": f, "formato": fmt, "muestras": int(a.shape[0]), "OI": r["OI"], "finito": finito})
    except Exception as e:
        print(f"  {f[:29]:<30}ERROR: {e}"); ra.append({"archivo": f, "error": str(e)})
RES["A_formatos"] = ra

# ---------- B. Estructura vs energía (misma RMS) ----------
print("\n" + "=" * 104); print("SUITE B — Estructura vs energía (estímulos normalizados a misma RMS=0.12, todos ON)"); print("=" * 104)
B = {"tono(demo)": "demo:tono", "ruido_blanco": "Ruido blanco_neg60deg.wav",
     "voz": "Voz_Estudio_pos60deg.wav", "musica": "musica_pos60deg.wav", "clasica(Brand.)": "Brandemburgo.wav"}
print(f"  {'estímulo':<18}{'OI':>7}{'XE':>7}{'C_m_pico':>9}{'R2':>7}{'Lambda':>9}{'e_R':>7}{'Omega':>8}")
rb = []
for nom, spec in B.items():
    _, a, _ = cargar_mono(spec, rms=0.12)
    r = run_audio(a, False, guardar=f"bateria_B_{nom.split('(')[0]}")
    print(f"  {nom:<18}{r['OI']:>7}{r['XE']:>7}{r['C_m_pico']:>9}{r['R2']:>7}{r['Lambda']:>9}{r['e_R']:>7}{r['Omega']:>8}")
    rb.append({"estimulo": nom, **{k: r[k] for k in ["OI", "XE", "C_m_pico", "R2", "Lambda", "e_R", "Omega"]}})
RES["B_estructura_vs_energia"] = rb

# ---------- C. Binaural vs mono ----------
print("\n" + "=" * 104); print("SUITE C — Binaural (canales propios) vs Mono (mezcla), mismo archivo espacializado"); print("=" * 104)
rc = []
for f in ["BigBang_pos60deg.wav", "Voz_Estudio_pos60deg.wav"]:
    _, amono, _ = cargar_mono(f)
    iz, de, real = cmf._load_wav(os.path.join(AUD, f), binaural=True)
    rm = run_audio(amono, False, guardar=f"bateria_C_{f[:10]}_mono")
    rb_ = run_audio((iz, de), True, guardar=f"bateria_C_{f[:10]}_binaural")
    print(f"  {f}")
    print(f"     mono     : OI={rm['OI']}  C_m={rm['C_m_pico']}  lateralidad={rm['lateralidad']}  coher={rm['coher']}")
    print(f"     binaural : OI={rb_['OI']}  C_m={rb_['C_m_pico']}  lateralidad={rb_['lateralidad']}  coher={rb_['coher']}  lat_real={rb_['lat_real']}")
    rc.append({"archivo": f, "mono": {k: rm[k] for k in ["OI","C_m_pico","lateralidad","coher"]},
               "binaural": {k: rb_[k] for k in ["OI","C_m_pico","lateralidad","coher","lat_real"]}})
RES["C_binaural_vs_mono"] = rc

# ---------- D. Asimetría L/R (swap de oídos) ----------
print("\n" + "=" * 104); print("SUITE D — Asimetría L/R: voz/ruido y su swap (¿importa qué oído recibe qué?)"); print("=" * 104)
_, voz, _ = cargar_mono("voz_neg60deg.wav", rms=0.12)
_, rui, _ = cargar_mono("Ruido blanco_neg60deg.wav", rms=0.12)
n = min(len(voz), len(rui)); voz, rui = voz[:n], rui[:n]
d1 = run_audio((voz, rui), True, guardar="bateria_D_vozL_ruidoR")
d2 = run_audio((rui, voz), True, guardar="bateria_D_ruidoL_vozR")
print(f"  voz→L, ruido→R : OI={d1['OI']}  balance={d1['balance']}  lateralidad={d1['lateralidad']}  coher={d1['coher']}")
print(f"  ruido→L, voz→R : OI={d2['OI']}  balance={d2['balance']}  lateralidad={d2['lateralidad']}  coher={d2['coher']}")
RES["D_swap_LR"] = {"vozL_ruidoR": {k: d1[k] for k in ["OI","balance","lateralidad","coher"]},
                    "ruidoL_vozR": {k: d2[k] for k in ["OI","balance","lateralidad","coher"]}}

# ---------- E. Ablación / anatomía funcional ----------
print("\n" + "=" * 104); print("SUITE E — Anatomía funcional (ablación) sobre Voz_Estudio_pos60deg (binaural)"); print("=" * 104)
iz, de, _ = cmf._load_wav(os.path.join(AUD, "Voz_Estudio_pos60deg.wav"), binaural=True)
ABL = [("TODO_ON", {}), ("sin_R2", {"meta_representacion": False}), ("sin_LF", {"LF": False}),
       ("sin_Exaptacion", {"exaptacion": False}), ("sin_C_m", {"consciencia_metacognitiva": False}),
       ("sin_Homeostasis", {"homeostasis::x_interna": False})]
print(f"  {'config':<18}{'OI':>7}{'R2':>7}{'XE':>7}{'C_m':>7}{'ΔOI':>9}")
re_ = []; base = None
for nom, tg in ABL:
    r = run_audio((iz, de), True, toggles=tg, guardar=f"bateria_E_{nom}")
    if base is None: base = r["OI"]
    print(f"  {nom:<18}{r['OI']:>7}{r['R2']:>7}{r['XE']:>7}{r['C_m_pico']:>7}{(r['OI']-base):>+9.3f}")
    re_.append({"config": nom, "OI": r["OI"], "R2": r["R2"], "XE": r["XE"], "C_m_pico": r["C_m_pico"], "dOI": round(r["OI"]-base, 4)})
RES["E_ablacion"] = re_

# ---------- F. Determinismo ----------
print("\n" + "=" * 104); print("SUITE F — Determinismo (misma corrida 2 veces → CSV idéntico)"); print("=" * 104)
_, a, _ = cargar_mono("La_pos60deg.wav")
r1 = run_audio(a, False); r2 = run_audio(a, False)
csv1 = "\n".join(",".join(str(x[c]) for c in W.COLS) for x in r1["_csv"])
csv2 = "\n".join(",".join(str(x[c]) for c in W.COLS) for x in r2["_csv"])
ident = csv1 == csv2
print(f"  La_pos60deg ×2 → idéntico bit a bit: {ident}")
RES["F_determinismo"] = {"identico": ident}

# ---------- resumen JSON ----------
for v in RES.get("C_binaural_vs_mono", []): pass
ruta = f"CelulaMadre_logs/bateria_resumen_{TS}.json"
with open(ruta, "w", encoding="utf-8") as f:
    json.dump(RES, f, indent=2, ensure_ascii=False)
print(f"\n  📁 Resumen: {ruta}  ·  CSVs por corrida: CelulaMadre_logs/bateria_*.csv")
