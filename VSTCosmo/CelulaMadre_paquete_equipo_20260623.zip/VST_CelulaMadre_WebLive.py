#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
VST_CelulaMadre_WebLive — LABORATORIO DE OBSERVACIÓN EN VIVO DE LA CÉLULA MADRE
================================================================================
Siguiente versión de la interfaz (Req 1-10). Backend Python (stdlib, sin deps nuevas
salvo OPCIONAL `sounddevice` para audio en vivo). NO reemplaza `VST_CelulaMadre_Web.py`
(que queda intacto) ni el motor validado: lo ENVUELVE.

QUÉ APORTA vs la interfaz anterior
  · Entrada BIAURAL real: dos canales (un archivo por oído, o estéreo, o mono duplicado).
  · Selector directo de audios del proyecto (/audios) — canal L y canal R.
  · Audio EN VIVO (micrófono / sistema vía BlackHole) — OPCIONAL, requiere sounddevice.
  · Gráficos EN TIEMPO REAL por streaming SSE (no al final).
  · 8 ventanas fisiológicas + timeline de eventos.
  · Monitor compacto / Laboratorio completo. Ablación por interruptor (real).
  · CSV con columnas antiguas (compat) + binaurales + de observación, y metadatos de apagados.

QUÉ ES REAL vs ANDAMIAJE (trazabilidad, Req 8)
  · REAL: el motor (campo Φ + organelos), las señales binaurales (energías/coherencia/
    lateralidad), la ablación (expresar=False saca del ciclo), el streaming de cada paso.
  · ANDAMIAJE/SIMULACIÓN: "biauralizar mono" (delay+gain interaural) — claramente marcado
    como simulación, no biaural real. El audio del SISTEMA en macOS requiere un dispositivo
    de loopback (BlackHole/Loopback): sin él, macOS NO entrega el audio del sistema al programa.

CÓMO CORRER
    venv/bin/python3 VST_CelulaMadre_WebLive.py   → http://localhost:7788
================================================================================
"""
from __future__ import annotations
import os, sys, json, base64, tempfile, glob, threading, queue, time
import numpy as np
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# Reutiliza el motor validado y el catálogo de organelos de la interfaz anterior
from VST_CelulaMadre_Web import cmf, ORG_UI

PUERTO = 7788
SR = cmf.SR
DT = cmf.DT
AQUI = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.join(AQUI, "audio_binaural")

# --- Audio en vivo: OPCIONAL (sounddevice). Si no está, se degrada con instrucciones. ---
try:
    import sounddevice as _sd
    SD_OK = True; SD_ERR = ""
except Exception as e:                                  # ImportError u OSError (PortAudio)
    _sd = None; SD_OK = False; SD_ERR = f"{type(e).__name__}: {e}"

# --- Columnas del CSV: 22 ANTIGUAS (compat) + binaurales + observación ---
COLS_BASE = ["t", "Omega", "omega_A", "omega_B", "gradiente", "e_R", "A_sys_env",
             "presion_desacople", "C_b", "R2", "LF_op", "lf_nivel", "juego", "ritual",
             "negacion", "demanda_entorno", "Omega_op", "XE", "C_m", "H_homeostasis",
             "OI", "Lambda_Cos"]
COLS_BIN = ["omega_L", "omega_R", "omega_A_L", "omega_A_R", "energia_L", "energia_R",
            "balance_LR", "lateralidad", "coherencia_biaural"]
COLS_OBS = ["LF_struct", "self_coherencia", "x_interna", "en_rango", "mutacion",
            "adaptacion_activa", "exaptacion_activa", "activacion_latente", "invariantes_ok"]
COLS = COLS_BASE + COLS_BIN + COLS_OBS


def _fila(cel) -> dict:
    """Una fila (dict col->valor) leída del milieu + salud, para CSV y streaming."""
    m = cel.milieu; s = cel.salud()
    g = lambda k, d=0.0: m.leer(k, d)
    inv = sum(1 for v in s["invariantes"].values() if v)
    d = {
        "t": round(cel.t, 3), "Omega": round(g("Omega"), 4), "omega_A": round(g("omega_A"), 4),
        "omega_B": round(g("omega_B"), 4), "gradiente": round(g("gradiente"), 4),
        "e_R": round(g("e_R"), 4), "A_sys_env": round(g("A_sys_env"), 4),
        "presion_desacople": round(g("presion_desacople"), 3), "C_b": int(g("C_b", 0)),
        "R2": round(g("R2"), 4), "LF_op": round(g("LF_op"), 4), "lf_nivel": int(g("lf_nivel", 0)),
        "juego": int(bool(g("juego_activo", False))), "ritual": int(bool(g("ritual_activo", False))),
        "negacion": int(bool(g("negacion_activa", False))), "demanda_entorno": round(g("demanda_entorno", 1.0), 4),
        "Omega_op": round(g("Omega_op", 1.0), 4), "XE": round(min(1.0, g("XE")), 4),
        "C_m": round(g("C_m"), 4), "H_homeostasis": round(g("H_homeostasis"), 4),
        "OI": round(s["OI"], 4), "Lambda_Cos": round(s["Lambda_Cos"], 5),
        # binaurales
        "omega_L": round(g("omega_L"), 4), "omega_R": round(g("omega_R"), 4),
        "omega_A_L": round(g("omega_A_L"), 4), "omega_A_R": round(g("omega_A_R"), 4),
        "energia_L": round(g("energia_L"), 5), "energia_R": round(g("energia_R"), 5),
        "balance_LR": round(g("balance_LR"), 4), "lateralidad": round(g("lateralidad"), 4),
        "coherencia_biaural": round(g("coherencia_biaural"), 4),
        # observación
        "LF_struct": round(g("LF_struct"), 4), "self_coherencia": round(g("self_coherencia"), 4),
        "x_interna": round(g("x_interna", 0.5), 4), "en_rango": int(bool(g("x_interna_en_rango", False))),
        "mutacion": round(g("mutacion"), 5), "adaptacion_activa": int(bool(g("adaptacion_activa", False))),
        "exaptacion_activa": int(bool(g("exaptacion_activa", False))),
        "activacion_latente": int(bool(g("demanda_activacion", False))), "invariantes_ok": inv,
    }
    return d


# ==============================================================================
# CARGA DE AUDIO (mono, dos canales, demo, upload, biauralización, en vivo)
# ==============================================================================
def _mono_de_spec(spec: str):
    """Devuelve (nombre, vector mono 48kHz) desde 'demo:...' o un .wav (de audio_binaural)."""
    if spec.startswith("demo:"):
        return cmf.cargar_audio(spec, binaural=False)
    path = spec if os.path.isabs(spec) else os.path.join(AUDIO_DIR, spec)
    return os.path.splitext(os.path.basename(path))[0], cmf._load_wav(path, binaural=False)

def _mono_de_upload(b64: str, etiqueta: str):
    raw = b64.split(",", 1)[1] if "," in b64 else b64
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False); tmp.write(base64.b64decode(raw)); tmp.close()
    try:
        return etiqueta, cmf._load_wav(tmp.name, binaural=False)
    finally:
        os.unlink(tmp.name)

def _carga_upload_binaural(b64: str, etiqueta: str):
    """Carga un upload usando sus PROPIOS canales L/R (binaural real; duplica si es mono)."""
    raw = b64.split(",", 1)[1] if "," in b64 else b64
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False); tmp.write(base64.b64decode(raw)); tmp.close()
    try:
        _, audio = cmf.cargar_audio(tmp.name, binaural=True)
        return etiqueta, audio
    finally:
        os.unlink(tmp.name)

def biauralizar_mono(mono, delay_ms=0.3, gain_L=1.0, gain_R=0.95):
    """SIMULACIÓN biaural (NO real): de un mono genera L/R con microdiferencia interaural
    (delay + ganancia). Marcado como simulación. Valores prudentes por defecto."""
    d = int(round(delay_ms * 1e-3 * SR))
    izq = mono * float(gain_L)
    der = (np.concatenate([np.zeros(d), mono[:len(mono) - d]]) if d > 0 else mono.copy()) * float(gain_R)
    return izq, der

def _alinear(a, b, criterio="min"):
    if len(a) == len(b):
        return a, b, "igual_duracion"
    if criterio == "pad":
        n = max(len(a), len(b))
        return (np.concatenate([a, np.zeros(n - len(a))]),
                np.concatenate([b, np.zeros(n - len(b))]), "relleno_silencio_a_max")
    n = min(len(a), len(b))
    return a[:n], b[:n], "truncado_a_duracion_menor"


# ==============================================================================
# DOS FUENTES INDEPENDIENTES por oído (Req: selector L / selector R)
# Cada oído resuelve a un vector mono desde: archivo, demo, upload, o UN CANAL de un
# dispositivo de entrada (p.ej. un canal individual de la Rødecaster Pro II 16ch).
# ==============================================================================
def _extraer_canal(rec, ci: int):
    """Extrae SOLO el canal `ci` de un buffer (N x canales). NO mezcla los canales.
    Testeable sin hardware: dado un buffer multicanal, devuelve la columna pedida."""
    rec = np.asarray(rec, dtype=np.float64)
    if rec.ndim == 1:
        return rec
    return rec[:, ci]

def _grabar_dispositivo(device_index: int, channels: int, seg: float):
    """Graba `seg` segundos de un dispositivo (N x channels). REAL si hay sounddevice."""
    if not SD_OK:
        raise RuntimeError("Audio en vivo NO disponible (sounddevice no instalado: "
                           f"{SD_ERR}). Instala: venv/bin/pip install sounddevice (requiere "
                           "PortAudio: brew install portaudio). Para AUDIO DEL SISTEMA en macOS: "
                           "brew install blackhole-2ch y elígelo como entrada.")
    rec = _sd.rec(int(seg * SR), samplerate=SR, channels=channels, device=device_index)
    _sd.wait()
    return np.asarray(rec, dtype=np.float64)

def _resolver_fuente(src: dict, seg: float = 10.0):
    """Resuelve UN descriptor de fuente → (nombre, vector mono 48kHz).
    src.tipo ∈ {archivo, demo, upload, dispositivo}. Para 'dispositivo' graba ese device
    y extrae SOLO src.channel_index (no mezcla canales)."""
    t = (src or {}).get("tipo")
    if t == "archivo":
        return _mono_de_spec(src["nombre"])
    if t == "demo":
        return cmf.cargar_audio(src.get("spec", "demo:tono"), binaural=False)
    if t == "upload":
        return _mono_de_upload(src["b64"], src.get("name", "subido"))
    if t == "dispositivo":
        di = int(src["device_index"]); ci = int(src["channel_index"])
        nch = ci + 1
        if SD_OK:
            try: nch = max(nch, int(_sd.query_devices(di).get("max_input_channels", nch)))
            except Exception: pass
        rec = _grabar_dispositivo(di, nch, seg)
        nom = (_sd.query_devices(di).get("name", f"dev{di}") if SD_OK else f"dev{di}")
        return (f"{nom} — canal {ci + 1}", _extraer_canal(rec, ci))
    raise ValueError(f"tipo de fuente desconocido: {t!r}")

def _build_audio_por_oido(cfg: dict):
    """Modelo NUEVO: left_src / right_src son descriptores independientes por oído.
    Caso especial: si ambos son canales del MISMO dispositivo, se graba UN solo stream
    sincronizado y se extraen las dos columnas (no dos grabaciones desfasadas)."""
    seg = float(cfg.get("segundos", 10)); crit = cfg.get("criterio_duracion", "min")
    ls, rs = cfg.get("left_src"), cfg.get("right_src")
    meta = {"fuente": "por_oido", "criterio_duracion": "-", "simulacion_biaural": False}

    # mismo dispositivo, dos canales → un stream sincronizado, dos columnas
    if (ls and rs and ls.get("tipo") == "dispositivo" and rs.get("tipo") == "dispositivo"
            and ls.get("device_index") == rs.get("device_index")):
        di = int(ls["device_index"]); cL = int(ls["channel_index"]); cR = int(rs["channel_index"])
        nch = max(cL + 1, cR + 1)
        if SD_OK:
            try: nch = max(nch, int(_sd.query_devices(di).get("max_input_channels", nch)))
            except Exception: pass
        rec = _grabar_dispositivo(di, nch, seg)
        nom = (_sd.query_devices(di).get("name", f"dev{di}") if SD_OK else f"dev{di}")
        meta.update(izquierdo=f"{nom} — canal {cL+1}", derecho=f"{nom} — canal {cR+1}",
                    fuente="dispositivo (1 stream, 2 canales)")
        return (_extraer_canal(rec, cL), _extraer_canal(rec, cR)), True, meta

    if ls and rs:                                    # dos fuentes independientes
        nL, L = _resolver_fuente(ls, seg); nR, R = _resolver_fuente(rs, seg)
        L, R, c = _alinear(L, R, crit)
        meta.update(izquierdo=nL, derecho=nR, criterio_duracion=c); return (L, R), True, meta

    src = ls or rs                                   # una sola fuente
    nom, mono = _resolver_fuente(src, seg)
    if cfg.get("binaural"):                          # duplicar a L/R (sin lateralidad real)
        meta.update(izquierdo=nom, derecho=nom + " (duplicado)"); return (mono, mono.copy()), True, meta
    meta.update(izquierdo=nom, derecho=nom); return mono, False, meta


def build_audio(cfg: dict):
    """Resuelve la configuración de entrada → (audio, binaural, meta). audio = vector mono
    o (izq, der). meta documenta fuente, canales, criterio de duración y si la lateralidad es real."""
    # MODELO NUEVO (dos selectores independientes): si hay left_src/right_src, úsalo.
    if cfg.get("left_src") or cfg.get("right_src"):
        return _build_audio_por_oido(cfg)
    # ---- MODELO PREVIO (preservado intacto): fuente/left/right ----
    bia = cfg.get("biauralizar") or {}
    fuente = cfg.get("fuente", "demo")
    crit_dur = cfg.get("criterio_duracion", "min")
    meta = {"fuente": fuente, "criterio_duracion": "-", "simulacion_biaural": False}

    # ---------- AUDIO EN VIVO (grabar N s y procesar; REAL si hay dispositivo) ----------
    if fuente == "vivo":
        if not SD_OK:
            raise RuntimeError("Audio en vivo NO disponible (sounddevice no instalado: "
                               f"{SD_ERR}). Instala:  venv/bin/pip install sounddevice  "
                               "(requiere PortAudio: brew install portaudio). Para AUDIO DEL SISTEMA "
                               "en macOS necesitas BlackHole (brew install blackhole-2ch) y elegirlo "
                               "como dispositivo de entrada.")
        v = cfg.get("vivo", {}); seg = float(v.get("segundos", 10)); dev = v.get("device")
        rec = np.asarray(_sd.rec(int(seg * SR), samplerate=SR, channels=2, device=dev), dtype=np.float64)
        _sd.wait()
        if rec.ndim == 2 and rec.shape[1] >= 2 and not np.array_equal(rec[:, 0], rec[:, 1]):
            meta.update(izquierdo="vivo:canal1", derecho="vivo:canal2"); return (rec[:, 0], rec[:, 1]), True, meta
        mono = rec.reshape(-1) if rec.ndim == 1 else rec[:, 0]
        if bia.get("on"):
            izq, der = biauralizar_mono(mono, bia.get("delay_ms", 0.3), bia.get("gain_L", 1.0), bia.get("gain_R", 0.95))
            meta.update(izquierdo="vivo (simulado L)", derecho="vivo (simulado R)", simulacion_biaural=True)
            return (izq, der), True, meta
        meta.update(izquierdo="vivo (mono)", derecho="vivo (mono)"); return mono, False, meta

    # ---------- ¿DOS fuentes distintas? -> monoizar cada una -> L/R (fuentes diferentes) ----------
    if fuente == "upload":
        left_b64 = cfg.get("left_b64"); right_b64 = cfg.get("right_b64"); dos = bool(right_b64)
    else:
        left = cfg.get("left") or "demo:tono"; right = cfg.get("right")
        dos = bool(right and right not in ("__mismo", "", None) and right != left)
    if dos:
        if fuente == "upload":
            nomL, Lm = _mono_de_upload(left_b64, cfg.get("left_name", "subido_L"))
            nomR, Rm = _mono_de_upload(right_b64, cfg.get("right_name", "subido_R"))
        else:
            nomL, Lm = _mono_de_spec(left); nomR, Rm = _mono_de_spec(right)
        Lm, Rm, crit = _alinear(Lm, Rm, crit_dur)
        meta.update(izquierdo=nomL, derecho=nomR, criterio_duracion=crit)
        return (Lm, Rm), True, meta

    # ---------- UNA sola fuente ----------
    spec = None if fuente == "upload" else (cfg.get("left") or "demo:tono")
    b64 = cfg.get("left_b64") if fuente == "upload" else None
    nomU = cfg.get("left_name", "subido") if fuente == "upload" else None

    # SIMULACIÓN biaural desde mono (delay+gain interaural) — marcada como simulación
    if bia.get("on"):
        nom, mono = (_mono_de_upload(b64, nomU) if b64 is not None else _mono_de_spec(spec))
        izq, der = biauralizar_mono(mono, bia.get("delay_ms", 0.3), bia.get("gain_L", 1.0), bia.get("gain_R", 0.95))
        meta.update(izquierdo=nom + " (sim L)", derecho=nom + " (sim R)", simulacion_biaural=True)
        return (izq, der), True, meta

    # DEMO (mono de origen): mono, o duplicado a L/R si se pide binaural
    if spec and spec.startswith("demo:"):
        if cfg.get("binaural"):
            nom, audio = cmf.cargar_audio(spec, binaural=True)        # demo mono -> duplicado
            meta.update(izquierdo=nom, derecho=nom + " (duplicado)"); return audio, True, meta
        nom, mono = cmf.cargar_audio(spec, binaural=False)
        meta.update(izquierdo=nom, derecho=nom); return mono, False, meta

    # ARCHIVO / UPLOAD de UN archivo: usar sus PROPIOS canales L/R (BINAURAL REAL; dup si es mono).
    # Clave: un .wav espacializado (p.ej. *_pos60deg) trae la lateralidad EN sus canales; NO monoizar.
    if b64 is not None:
        nom, audio = _carga_upload_binaural(b64, nomU)
    else:
        path = spec if os.path.isabs(spec) else os.path.join(AUDIO_DIR, spec)
        nom, audio = cmf.cargar_audio(path, binaural=True)
    meta.update(izquierdo=str(nom) + " (canal L)", derecho=str(nom) + " (canal R)")
    return audio, True, meta


def build_cell(cfg: dict, toggles: dict):
    """Construye la célula desde la config, aplica ablación, devuelve (cel, soma, meta)."""
    audio, binaural, meta = build_audio(cfg)
    cel = cmf.celula_madre_funcional(audio, binaural=binaural)
    apagados = []
    for name, org in cel.organelos.items():
        if name == "soma":
            continue
        if not toggles.get(name, True):
            org.expresar = False; apagados.append(name)
    soma = cel.organelos["soma"]
    meta.update(binaural=bool(binaural), lateralidad_real=bool(getattr(soma, "lateralidad_real", False)),
                apagados=apagados, dur=round(soma.dur, 3), muestras=int(len(soma._L)))
    return cel, soma, meta


# ==============================================================================
# CORRIDA — streaming (Run/worker) y no-streaming (para pruebas)
# ==============================================================================
def _csv_de_rows(rows, meta):
    """CSV con metadatos comentados (Req 7) + cabecera + filas. Columnas antiguas incluidas."""
    cab = (f"# apagados: {','.join(meta.get('apagados') or []) or 'ninguno'}\n"
           f"# binaural: {meta.get('binaural')} | lateralidad_real: {meta.get('lateralidad_real')} | "
           f"fuente: {meta.get('fuente')} | criterio_duracion: {meta.get('criterio_duracion')}\n"
           f"# izquierdo: {meta.get('izquierdo')} | derecho: {meta.get('derecho')}\n")
    return cab + ",".join(COLS) + "\n" + "\n".join(",".join(str(r[c]) for c in COLS) for r in rows)


def correr(cfg: dict, toggles: dict, sim_s: float):
    """Corrida NO-streaming (para pruebas/CLI). Devuelve dict con cols, csv, rows, meta."""
    cel, soma, meta = build_cell(cfg, toggles)
    sim = min(soma.dur, float(sim_s))
    pasos = max(1, int(sim / DT))
    rows = []
    for _ in range(pasos):
        cel.vivir_un_paso(DT)
        rows.append(_fila(cel))
    meta["sim_s"] = round(sim, 2); meta["pasos"] = pasos
    return {"cols": COLS, "csv": _csv_de_rows(rows, meta), "rows": rows, "meta": meta}


class Run:
    """Una corrida en streaming: hilo trabajador que empuja una fila por paso a una cola.
    Soporta pausa/reanudar/detener. Acumula filas para descargar CSV parcial o final."""
    def __init__(self, cel, soma, meta, sim_s):
        self.cel, self.soma, self.meta = cel, soma, meta
        self.sim = min(soma.dur, float(sim_s)); self.pasos = max(1, int(self.sim / DT))
        self.q = queue.Queue(); self.rows = []
        self.stop = False; self.paused = False; self.done = False
        meta["sim_s"] = round(self.sim, 2); meta["pasos_total"] = self.pasos
        self.thread = threading.Thread(target=self._loop, daemon=True)

    def start(self): self.thread.start()

    def _loop(self):
        for _ in range(self.pasos):
            if self.stop:
                break
            while self.paused and not self.stop:
                time.sleep(0.05)
            self.cel.vivir_un_paso(DT)
            fila = _fila(self.cel)
            self.rows.append(fila)
            self.q.put(fila)
            time.sleep(0.004)                  # ritmo observable (no inunda el SSE)
        self.done = True
        self.q.put(None)                       # centinela de fin

    def csv(self): return _csv_de_rows(self.rows, self.meta)


RUN: "Run|None" = None
RUN_LOCK = threading.Lock()


# ==============================================================================
# FRONTEND (tema oscuro · pestañas · 8 ventanas · compacto/completo · SSE)
# ==============================================================================
HTML = r"""<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Célula Madre — Laboratorio en vivo</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{--bg:#0a0e14;--panel:#121925;--ink:#dfe7f0;--mut:#8aa0b8;--gold:#e8b86d;--ok:#5fd38a;--bad:#ff6b6b;--line:#243246;--blue:#6db6ff;--org:#ff8c6b;--pur:#b58cff;}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:13px/1.4 'Helvetica Neue',Arial,sans-serif}
h1{font-size:17px;margin:0;color:var(--gold)}h2{font-size:12px;color:var(--gold);text-transform:uppercase;letter-spacing:.05em;margin:0 0 6px}
.wrap{display:grid;grid-template-columns:330px 1fr;gap:12px;padding:12px;max-width:1500px;margin:auto}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px;margin-bottom:12px}
label.fld{display:block;color:var(--mut);font-size:10.5px;margin:8px 0 3px;text-transform:uppercase;letter-spacing:.04em}
select,input[type=number],input[type=text]{background:#0c121b;color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:6px;width:100%}
button{background:#1b2636;color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:7px 10px;cursor:pointer;font-size:12px}
button:hover{border-color:var(--gold)}button.go{background:var(--gold);color:#1a1206;font-weight:bold;border:none}
button.csv{border-color:var(--gold);color:var(--gold)}button.sm{padding:5px 8px;font-size:11px}
.row{display:flex;gap:6px;align-items:center;margin-top:8px;flex-wrap:wrap}
.tog{display:flex;align-items:center;gap:7px;padding:2px 0}.tog input{accent-color:var(--gold);width:15px;height:15px}
.tog.req label{color:var(--mut)}.gt{color:var(--mut);font-size:10px;text-transform:uppercase;margin:7px 0 3px}
.tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px}
.tab{padding:5px 9px;border:1px solid var(--line);border-radius:6px;cursor:pointer;font-size:11.5px;background:#0c121b;color:var(--mut)}
.tab.on{background:var(--gold);color:#1a1206;border:none;font-weight:bold}
.win{display:none}.win.on{display:block}
.canwrap{position:relative;height:200px;background:#0c121b;border:1px solid var(--line);border-radius:6px;padding:4px;margin-bottom:8px}
.status{display:flex;gap:14px;flex-wrap:wrap;font-size:11px;color:var(--mut);margin-bottom:8px}
.status b{color:var(--ink)}
.big{font-size:22px;color:var(--gold);font-weight:bold}
#ev{font:11px/1.5 'SF Mono',Menlo,monospace;background:#070a0f;border:1px solid var(--line);border-radius:6px;padding:8px;height:240px;overflow:auto}
.fuente-box{display:none}.fuente-box.on{display:block}
.mut{color:var(--mut)}.ok{color:var(--ok)}.bad{color:var(--bad)}.warn{color:var(--gold)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
</style></head><body>
<div class="wrap">
  <!-- ================= CONTROLES ================= -->
  <div>
    <div class="panel">
      <h1>🧬 Célula Madre — Laboratorio en vivo</h1>
      <div class="mut">Entrada biaural · observación en tiempo real · ablación real</div>

      <div class="mut" style="font-size:10.5px">Dos entradas INDEPENDIENTES. Cada una = un canal de
        dispositivo (p.ej. Rødecaster 16ch) o un archivo. Pueden ser distintas.</div>

      <label class="fld">🟦 Entrada izquierda → hemisferio L</label>
      <select id="selL"></select>
      <input type="file" id="upL" accept=".wav" style="display:none;margin-top:6px">

      <label class="fld">🟥 Entrada derecha → hemisferio R</label>
      <select id="selR"></select>
      <input type="file" id="upR" accept=".wav" style="display:none;margin-top:6px">

      <div id="fuentesMsg" class="mut" style="font-size:10.5px;margin-top:6px"></div>
      <div class="grid2">
        <div><label class="fld">Captura en vivo (s)</label><input type="number" id="capSeg" value="10" min="1" max="60"></div>
        <div><label class="fld">&nbsp;</label><button class="sm" id="bAuto" style="width:100%">Auto-par pos/neg (R)</button></div>
      </div>

      <label class="fld">Segundos de simulación</label>
      <input type="number" id="sim" value="6" min="1" max="60" step="1">
      <div class="row">
        <button class="go" id="bStart" style="flex:1">▶ Iniciar</button>
        <button class="sm" id="bPause">⏸</button><button class="sm" id="bStop">⏹</button>
      </div>
      <div class="row">
        <button class="sm" id="bClear">Limpiar</button>
        <button class="csv sm" id="bCsv" style="flex:1">⬇ CSV (parcial/final)</button>
      </div>
    </div>

    <div class="panel">
      <h2>Organelos (interruptores · ablación real)</h2>
      <div id="toggles"></div>
      <div class="row"><button class="sm" id="tAll">Todos</button><button class="sm" id="tNone">Solo soma</button></div>
    </div>
  </div>

  <!-- ================= OBSERVACIÓN ================= -->
  <div>
    <div class="panel">
      <div class="row" style="justify-content:space-between">
        <div><button class="tab on" id="mCompacto" onclick="setModo('compacto')">Monitor compacto</button>
             <button class="tab" id="mCompleto" onclick="setModo('completo')">Laboratorio completo</button></div>
        <div id="estado" class="big">listo</div>
      </div>
      <div class="status" id="status"></div>
      <div class="tabs" id="winTabs"></div>
      <div id="wins"></div>
    </div>
  </div>
</div>
<script>
const $=id=>document.getElementById(id);
const SR_DT=0.1;
let cols=[], buf={}, charts={}, es=null, paused=false, modo='compacto', tabActual=null;
let nrec=0, t0=0, evPrev={};

// ---- definición de ventanas (Req 5) ----
const VENTANAS=[
 {id:'campo', tit:'Campo Φ / Soma', comp:true, series:[['Omega','Ω','#e8b86d'],['omega_A_L','ω_A_L','#6db6ff'],['omega_A_R','ω_A_R','#ff8c6b'],['omega_B','ω_B','#8aa0b8'],['gradiente','grad','#5fd38a']]},
 {id:'conciencia', tit:'Consciencia', comp:true, series:[['C_b','C_b','#e8b86d'],['R2','R₂','#6db6ff'],['self_coherencia','Self','#5fd38a'],['C_m','C_m','#b58cff']]},
 {id:'libertad', tit:'Libertad funcional', comp:true, series:[['LF_struct','LF_struct','#8aa0b8'],['LF_op','LF_op','#e8b86d'],['lf_nivel','nivel','#6db6ff'],['juego','juego','#5fd38a'],['ritual','ritual','#b58cff'],['negacion','No','#ff6b6b']]},
 {id:'salud', tit:'Salud del cierre', comp:true, series:[['OI','OI','#5fd38a'],['Lambda_Cos','Λ_Cos','#6db6ff'],['invariantes_ok','κ ok','#e8b86d'],['A_sys_env','A_env','#8aa0b8']]},
 {id:'biaural', tit:'Entrada biaural', comp:false, series:[['energia_L','energía_L','#6db6ff'],['energia_R','energía_R','#ff8c6b'],['balance_LR','balance','#e8b86d'],['coherencia_biaural','coherencia','#5fd38a'],['lateralidad','lateralidad','#b58cff']]},
 {id:'evolucion', tit:'Evolución', comp:false, series:[['Omega_op','Ωop','#e8b86d'],['XE','XE','#ff8c6b'],['mutacion','mutación','#8aa0b8'],['adaptacion_activa','adapt','#6db6ff'],['exaptacion_activa','exapt','#5fd38a'],['activacion_latente','latente','#b58cff']]},
 {id:'homeostasis', tit:'Homeostasis', comp:false, series:[['H_homeostasis','H','#5fd38a'],['x_interna','x','#e8b86d'],['en_rango','en_rango','#6db6ff'],['e_R','e_R','#ff6b6b']]},
 {id:'eventos', tit:'Eventos', comp:false, eventos:true},
];

function setModo(m){modo=m;$('mCompacto').classList.toggle('on',m==='compacto');$('mCompleto').classList.toggle('on',m==='completo');buildTabs();}
function buildTabs(){
  const tabs=$('winTabs'), wins=$('wins'); tabs.innerHTML='';
  const visibles=VENTANAS.filter(v=>modo==='completo'||v.comp||v.eventos);
  visibles.forEach((v,i)=>{
    const b=document.createElement('div');b.className='tab'+((tabActual===v.id||(tabActual===null&&i===0))?' on':'');
    b.textContent=v.tit;b.onclick=()=>{tabActual=v.id;buildTabs();};tabs.appendChild(b);
  });
  if(!visibles.find(v=>v.id===tabActual)) tabActual=visibles[0].id;
  wins.querySelectorAll('.win').forEach(w=>w.classList.remove('on'));
  let w=$('win-'+tabActual); if(w) w.classList.add('on');
}
function buildWins(){
  const wins=$('wins'); wins.innerHTML='';
  VENTANAS.forEach(v=>{
    const d=document.createElement('div');d.className='win';d.id='win-'+v.id;
    if(v.eventos){d.innerHTML=`<h2>${v.tit}</h2><div id="ev"></div>`;}
    else{d.innerHTML=`<h2>${v.tit}</h2><div class="canwrap"><canvas id="c-${v.id}"></canvas></div>`;}
    wins.appendChild(d);
  });
}
function mkChart(v){
  const ds=v.series.map(s=>({label:s[1],data:[],borderColor:s[2],borderWidth:1.6,tension:.2,pointRadius:0}));
  charts[v.id]=new Chart($('c-'+v.id),{type:'line',data:{labels:[],datasets:ds},
    options:{animation:false,responsive:true,maintainAspectRatio:false,
      scales:{x:{ticks:{color:'#8aa0b8',maxTicksLimit:8},grid:{color:'#1a2330'}},y:{ticks:{color:'#8aa0b8'},grid:{color:'#1a2330'}}},
      plugins:{legend:{labels:{color:'#dfe7f0',boxWidth:10,font:{size:10}}}}}});
}
function ev(msg,c){const d=document.createElement('div');if(c)d.className=c;d.textContent=msg;const e=$('ev');if(e)e.prepend(d);}

// ---- carga de listas (audios, organelos, dispositivos) ----
let FUENTES=[];   // descriptores unificados: demos + subir + canales de dispositivo + archivos
fetch('/fuentes').then(r=>r.json()).then(d=>{
  FUENTES=[
    {tipo:'demo',spec:'demo:tono',label:'▮ demo — tono 440Hz'},
    {tipo:'demo',spec:'demo:rosa',label:'▮ demo — ruido rosa'},
    {tipo:'demo',spec:'demo:clicks',label:'▮ demo — clicks Poisson'},
    {tipo:'subir',label:'⬆ subir archivo .wav…'},
    ...(d.dispositivos||[]), ...(d.archivos||[]),
  ];
  const opt=FUENTES.map((s,i)=>`<option value="${i}">${s.label}</option>`).join('');
  $('selL').innerHTML=opt;
  $('selR').innerHTML='<option value="__igual">— igual que izquierda —</option>'+opt;
  const nd=(d.dispositivos||[]).length, na=(d.archivos||[]).length, v=d.audio_vivo||{};
  $('fuentesMsg').innerHTML = nd
    ? `<span class=ok>🎙 ${nd} canal(es) de dispositivo</span> · ${na} archivos`
    : `<span class=warn>sin dispositivos de entrada</span> · ${na} archivos<br>${v.mensaje||''} ${v.instrucciones||''}`;
});
fetch('/organelos').then(r=>r.json()).then(list=>{
  const byG={};list.forEach(o=>{(byG[o.grupo]=byG[o.grupo]||[]).push(o);});
  const c=$('toggles');
  for(const g in byG){const h=document.createElement('div');h.className='gt';h.textContent=g;c.appendChild(h);
    byG[g].forEach(o=>{const w=document.createElement('div');w.className='tog'+(o.req?' req':'');
      w.innerHTML=`<input type="checkbox" id="t_${o.name}" ${o.req?'checked disabled':'checked'}><label for="t_${o.name}">${o.label}</label>`;c.appendChild(w);});}
});
// mostrar el input de archivo de cada oído solo si su fuente elegida es 'subir'
function syncUp(sel,up){const d=FUENTES[+sel.value];up.style.display=(d&&d.tipo==='subir')?'block':'none';}
$('selL').onchange=()=>syncUp($('selL'),$('upL'));
$('selR').onchange=()=>{if($('selR').value==='__igual')$('upR').style.display='none';else syncUp($('selR'),$('upR'));};
$('bAuto').onclick=()=>{const d=FUENTES[+$('selL').value];
  if(!d||d.tipo!=='archivo'){ev('Auto-par: elige un ARCHIVO en la entrada izquierda','bad');return;}
  const par=d.nombre.replace('pos60deg','neg60deg').replace('left','right').replace('_L','_R');
  const i=FUENTES.findIndex(s=>s.tipo==='archivo'&&s.nombre===par);
  if(i>=0){$('selR').value=i;$('upR').style.display='none';ev('Auto-par derecha: '+par,'ok');}else ev('No encontré par de '+d.nombre,'bad');};
$('tAll').onclick=()=>document.querySelectorAll('#toggles input:not([disabled])').forEach(c=>c.checked=true);
$('tNone').onclick=()=>document.querySelectorAll('#toggles input:not([disabled])').forEach(c=>c.checked=false);

// ---- construir config: dos fuentes independientes (left_src / right_src) ----
async function fileB64(inp){const f=inp.files[0];if(!f)return null;return await new Promise(r=>{const x=new FileReader();x.onload=()=>r(x.result);x.readAsDataURL(f);});}
async function srcDe(sel,up){const d=FUENTES[+sel.value];
  if(d.tipo==='subir')return {tipo:'upload',b64:await fileB64(up),name:(up.files[0]||{}).name};
  return d;}
async function buildCfg(){
  const left_src=await srcDe($('selL'),$('upL'));
  const right_src=($('selR').value==='__igual')?null:await srcDe($('selR'),$('upR'));
  const cfg={left_src,right_src,binaural:(right_src===null),segundos:+$('capSeg').value,criterio_duracion:'min'};
  const toggles={};document.querySelectorAll('#toggles input').forEach(c=>toggles[c.id.slice(2)]=c.checked);
  return {cfg,toggles,sim_s:+$('sim').value};
}

// ---- ciclo de vida de la corrida (SSE) ----
function limpiar(){buf={};nrec=0;cols.forEach(c=>buf[c]=[]);buf.t=[];evPrev={};
  Object.values(charts).forEach(ch=>{ch.data.labels=[];ch.data.datasets.forEach(d=>d.data=[]);ch.update('none');});$('ev').innerHTML='';}
async function start(){
  if(es){es.close();es=null;}
  const body=await buildCfg();
  $('estado').textContent='iniciando…';
  let r;try{r=await fetch('/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});}catch(e){$('estado').textContent='error';ev('Error: '+e,'bad');return;}
  const d=await r.json();
  if(d.error){$('estado').textContent='error';ev('Error: '+d.error,'bad');return;}
  cols=d.cols; limpiar(); pintarStatus(d.meta); paused=false; t0=performance.now(); nrec=0;
  ev('▶ inicio · '+(d.meta.izquierdo||'')+'  |  '+(d.meta.derecho||'')+(d.meta.simulacion_biaural?'  [SIM biaural]':''),'ok');
  es=new EventSource('/stream');
  es.onmessage=e=>{const row=JSON.parse(e.data);recibir(row);};
  es.addEventListener('fin',e=>{$('estado').textContent='terminado';ev('⏹ fin · '+nrec+' pasos','ok');es.close();es=null;});
  es.onerror=()=>{$('estado').textContent='(conexión cerrada)';};
}
function recibir(row){
  nrec++; buf.t.push(row.t); cols.forEach(c=>{(buf[c]=buf[c]||[]).push(row[c]);});
  detectarEventos(row);
  // actualizar solo la ventana visible (rendimiento)
  const v=VENTANAS.find(x=>x.id===tabActual);
  if(v&&!v.eventos&&charts[v.id]){const ch=charts[v.id];ch.data.labels=buf.t;
    v.series.forEach((s,i)=>{ch.data.datasets[i].data=buf[s[0]]||[];});ch.update('none');}
  if(nrec%5===0){const fps=(nrec/((performance.now()-t0)/1000)).toFixed(1);
    $('estado').textContent=row.OI!=null?('OI '+row.OI):'corriendo';
    pintarStatus(null,{pasos:nrec,fps});}
}
function detectarEventos(r){
  const mk=(k,cond,msg,cl)=>{if(cond&&!evPrev[k]){ev('t='+r.t+'  '+msg,cl);}evPrev[k]=cond;};
  mk('juego',r.juego>0,'▷ inicio JUEGO','warn');
  mk('ritual',r.ritual>0,'▷ inicio RITUAL','warn');
  mk('neg',r.negacion>0,'▷ inicio NEGACIÓN ("No")','warn');
  mk('exapt',r.exaptacion_activa>0,'▷ EXAPTACIÓN activa (XE='+r.XE+')','ok');
  mk('cm',r.C_m>0.3,'△ C_m sobre umbral ('+r.C_m+')','ok');
  mk('hbaja',r.H_homeostasis<0.3,'▽ H bajo umbral ('+r.H_homeostasis+')','bad');
  mk('lbaja',r.Lambda_Cos<0.005,'▽ Λ_Cos bajo umbral','bad');
  if(evPrev.lf!==r.lf_nivel){ev('t='+r.t+'  ⇅ nivel LF → '+r.lf_nivel,'warn');evPrev.lf=r.lf_nivel;}
}
function pintarStatus(meta,live){
  const s=$('status'); if(meta){s.dataset.izq=meta.izquierdo||'-';s.dataset.der=meta.derecho||'-';
    s.dataset.fte=meta.fuente;s.dataset.dur=meta.sim_s+'s';s.dataset.ap=(meta.apagados&&meta.apagados.length)?meta.apagados.join(','):'ninguno';
    s.dataset.crit=meta.criterio_duracion||'-';s.dataset.latr=meta.lateralidad_real;}
  const p=live?live.pasos:0, fps=live?live.fps:'0';
  s.innerHTML=`<span>L: <b>${s.dataset.izq||'-'}</b></span><span>R: <b>${s.dataset.der||'-'}</b></span>
    <span>fuente: <b>${s.dataset.fte||'-'}</b></span><span>lat.real: <b>${s.dataset.latr}</b></span>
    <span>dur: <b>${s.dataset.dur||'-'}</b></span><span>pasos: <b>${p||s.dataset.pasos||0}</b></span>
    <span>FPS: <b>${fps}</b></span><span>apagados: <b>${s.dataset.ap||'-'}</b></span>`;
  if(live){s.dataset.pasos=p;}
}
$('bStart').onclick=start;
$('bPause').onclick=()=>{paused=!paused;fetch('/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:paused?'pause':'resume'})});$('bPause').textContent=paused?'▶':'⏸';ev(paused?'⏸ pausa':'▶ reanuda','mut');};
$('bStop').onclick=()=>{fetch('/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'stop'})});ev('⏹ detener solicitado','mut');};
$('bClear').onclick=limpiar;
$('bCsv').onclick=()=>{fetch('/csv').then(r=>r.text()).then(txt=>{if(!txt){ev('sin datos','bad');return;}
  const b=new Blob([txt],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='celula_madre_live_'+new Date().toISOString().slice(0,19).replace(/[:.]/g,'-')+'.csv';a.click();ev('CSV descargado','ok');});};

buildWins(); VENTANAS.forEach(v=>{if(!v.eventos)mkChart(v);}); buildTabs();
ev('Laboratorio listo. Elige entrada y pulsa Iniciar.');
</script></body></html>"""


# ==============================================================================
# SERVIDOR
# ==============================================================================
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, code, body, ctype="application/json"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, HTML, "text/html")
        elif self.path == "/audios":
            wavs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(AUDIO_DIR, "*.wav")))
            self._send(200, json.dumps(wavs, ensure_ascii=False))
        elif self.path == "/organelos":
            self._send(200, json.dumps([{"name": n, "grupo": g, "label": l, "req": rq}
                                        for n, g, l, rq in ORG_UI], ensure_ascii=False))
        elif self.path == "/dispositivos":
            self._send(200, json.dumps(_dispositivos(), ensure_ascii=False))
        elif self.path == "/fuentes":
            self._send(200, json.dumps(_fuentes(), ensure_ascii=False))
        elif self.path == "/csv":
            self._send(200, RUN.csv() if RUN else "", "text/csv")
        elif self.path == "/stream":
            self._stream()
        else:
            self._send(404, json.dumps({"error": "no encontrado"}))

    def do_POST(self):
        try:
            if self.path == "/start":
                self._start(self._body())
            elif self.path == "/control":
                self._control(self._body())
            else:
                self._send(404, json.dumps({"error": "no encontrado"}))
        except Exception as e:
            import traceback; traceback.print_exc()
            self._send(200, json.dumps({"error": str(e)}))

    # ---- iniciar una corrida ----
    def _start(self, req):
        global RUN
        with RUN_LOCK:
            if RUN and not RUN.done:
                RUN.stop = True                       # detener corrida previa
            cel, soma, meta = build_cell(req.get("cfg", {}), req.get("toggles", {}))
            RUN = Run(cel, soma, meta, req.get("sim_s", 6))
            RUN.start()
        self._send(200, json.dumps({"cols": COLS, "meta": meta}, ensure_ascii=False))

    # ---- pausa / reanuda / detiene ----
    def _control(self, req):
        a = req.get("action")
        if RUN:
            if a == "pause": RUN.paused = True
            elif a == "resume": RUN.paused = False
            elif a == "stop": RUN.stop = True
        self._send(200, json.dumps({"ok": True}))

    # ---- streaming SSE: una fila por paso, en vivo ----
    def _stream(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        run = RUN
        try:
            while run is not None:
                try:
                    fila = run.q.get(timeout=1.0)
                except queue.Empty:
                    self.wfile.write(b": keepalive\n\n"); self.wfile.flush(); continue
                if fila is None:                       # centinela de fin
                    self.wfile.write(b"event: fin\ndata: {}\n\n"); self.wfile.flush(); break
                self.wfile.write(("data: " + json.dumps(fila) + "\n\n").encode("utf-8")); self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass                                       # el cliente cerró la pestaña


def _fuentes():
    """Lista UNIFICADA de fuentes seleccionables por oído: cada CANAL de cada dispositivo
    de entrada (max_input_channels>0) + los .wav de la carpeta del proyecto. La Rødecaster
    Pro II (16ch) aparece como 16 entradas 'nombre — canal n'."""
    archivos = [{"tipo": "archivo", "nombre": os.path.basename(p),
                 "label": "📄 " + os.path.basename(p)}
                for p in sorted(glob.glob(os.path.join(AUDIO_DIR, "*.wav")))]
    dispositivos, vivo = [], {"disponible": SD_OK}
    if SD_OK:
        try:
            for i, d in enumerate(_sd.query_devices()):
                nch = int(d.get("max_input_channels", 0))
                for c in range(nch):
                    dispositivos.append({"tipo": "dispositivo", "device_index": i, "channel_index": c,
                                         "nombre": d["name"], "canales": nch,
                                         "label": f"🎙 {d['name']} — canal {c + 1}"})
        except Exception as e:
            vivo = {"disponible": False, "mensaje": f"error consultando dispositivos: {e}"}
    else:
        vivo.update(mensaje=f"sounddevice no instalado ({SD_ERR})",
                    instrucciones="venv/bin/pip install sounddevice (brew install portaudio). "
                                  "Audio del SISTEMA en macOS: brew install blackhole-2ch y elígelo como entrada.")
    return {"dispositivos": dispositivos, "archivos": archivos, "audio_vivo": vivo}


def _dispositivos():
    """Lista dispositivos de entrada (sounddevice) o explica por qué no está disponible."""
    if not SD_OK:
        return {"disponible": False,
                "mensaje": f"sounddevice no instalado ({SD_ERR})",
                "instrucciones": "Instala:  venv/bin/pip install sounddevice  (requiere PortAudio: "
                                 "brew install portaudio). Para AUDIO DEL SISTEMA en macOS necesitas un "
                                 "dispositivo de loopback: brew install blackhole-2ch, y elige 'BlackHole 2ch' "
                                 "como entrada (macOS no entrega el audio del sistema directamente al programa)."}
    devs = []
    try:
        for i, d in enumerate(_sd.query_devices()):
            if d.get("max_input_channels", 0) > 0:
                devs.append({"index": i, "name": d["name"], "canales": d["max_input_channels"]})
    except Exception as e:
        return {"disponible": False, "mensaje": f"error consultando dispositivos: {e}", "instrucciones": ""}
    return {"disponible": True, "dispositivos": devs,
            "nota": "Para audio del SISTEMA elige un dispositivo de loopback (BlackHole/Loopback)."}


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PUERTO), Handler)
    print("=" * 66)
    print("  CÉLULA MADRE — LABORATORIO EN VIVO")
    print(f"  → abre:  http://localhost:{PUERTO}")
    print(f"  audio en vivo: {'DISPONIBLE' if SD_OK else 'no (sounddevice ausente)'}")
    print("  Ctrl+C para detener.")
    print("=" * 66)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  detenido."); srv.shutdown()


if __name__ == "__main__":
    main()
